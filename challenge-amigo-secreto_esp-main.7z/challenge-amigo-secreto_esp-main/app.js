// El principal objetivo de este desafío es fortalecer tus habilidades en lógica de programación. Aquí deberás desarrollar la lógica para resolver el problema.

let amigos = []; // Array para almacenar los nombres de amigos

function agregarAmigo() {
  // 1. Capturar el valor del campo de entrada
  const nombreInput = document.getElementById("nombreAmigo"); // Reemplaza "nombreAmigo" con el ID real de tu campo de entrada
  const nombre = nombreInput.value;

  // 2. Validar la entrada
  if (nombre.trim() === "") {
    alert("Por favor, inserte un nombre.");
    return; // Detener la función si el campo está vacío
  }

  // 3. Actualizar el array de amigos
  amigos.push(nombre);

  // 4. Limpiar el campo de entrada
  nombreInput.value = "";

  
  mostrarListaAmigos();
}

function mostrarListaAmigos() {
  const listaAmigosElement = document.getElementById("listaAmigos"); // Reemplaza "listaAmigos" con el ID de  elemento de lista
  listaAmigosElement.innerHTML = ""; // Limpiar la lista antes de actualizarla

  amigos.forEach(amigo => {
    const nuevoElemento = document.createElement("li");
    nuevoElemento.textContent = amigo;
    listaAmigosElement.appendChild(nuevoElemento);
  });
}


function mostrarAmigosEnLista() {
    // 1. Obtener el elemento de la lista
    const listaAmigos = document.getElementById("listaAmigos"); // Reemplaza "listaAmigos" con el ID real de lista
  
    // 2. Limpiar la lista existente
    listaAmigos.innerHTML = "";
  
    // 3. Iterar sobre el arreglo y agregar elementos a la lista
    for (let i = 0; i < amigos.length; i++) {
      const amigo = amigos[i];
  
      // Crear un nuevo elemento de lista (<li>)
      const nuevoElemento = document.createElement("li");
  
      // Agregar el nombre del amigo como texto al elemento de lista
      nuevoElemento.textContent = amigo;
  
      // Agregar el elemento de lista a la lista HTML
      listaAmigos.appendChild(nuevoElemento);
    }
  }